from logging import getLogger
from recbole.config import Config
from recbole.data import create_dataset, data_preparation
# from baselines.baseline_models.lightgcn import LightGCN
from baseline_models.simplex import SimpleX
# from recbole.model.general_recommender import BPR, LightGCN, NeuMF, SimpleX, DMF
from recbole.trainer import Trainer
from recbole.utils import init_seed, init_logger
from recbole.quick_start import run_recbole
import torch
import os

# os.environ["CUDA_VISIBLE_DEVICES"] = "3"

if __name__ == '__main__':

    # configurations initialization
    print("Data Loading for RecBole...")
    # config = Config(model='BERT4Rec', dataset='ml-latest-small', config_file_list=[
    #     "config/sequential_ml.yaml", "config/LLM.yaml", "config/baseline_models/DMF.yaml"])
    config = Config(model='BERT4Rec', dataset='Amazon_CDs_and_Vinyl_small', config_file_list=[
        "config/sequential_ml_amazon.yaml", "config/LLM.yaml", "config/baseline_models/simplex.yaml"])
    config.model = 'SimpleX'
    print("Model SimpleX; Dataset movielens")

    baseline_args = ["embedding_size",
                     "margin",
                     "negative_weight",
                     "gamma",
                     "aggregator",
                     "history_len",
                     "reg_weight",
                     "learning_rate"]
    args_dict = {}
    for per_arg in baseline_args:
        args_dict[per_arg] = config[per_arg]



    # init random seed
    init_seed(config['seed'], config['reproducibility'])

    # logger initialization
    init_logger(config)
    logger = getLogger()

    # write config info into log
    logger.info(config)

    # dataset creating and filtering
    dataset = create_dataset(config)
    logger.info(dataset)

    # dataset splitting
    train_data, valid_data, test_data = data_preparation(config, dataset)

    # model loading and initialization
    model = SimpleX(config, train_data.dataset).to(config['device'])
    logger.info(model)

    # trainer loading and initialization
    trainer = Trainer(config, model)

    config = Config(model='SimpleX', dataset='Amazon_CDs_and_Vinyl_small_b', config_file_list=[
                    "config/baseline.yaml", "config/baseline_models/simplex.yaml"])

    for per_arg in baseline_args:
        config[per_arg] = args_dict[per_arg]
        setattr(config, per_arg, args_dict[per_arg])

    baseline_dataset = create_dataset(config)
    train_data, valid_data, _ = data_preparation(config, baseline_dataset)

    # model training with baseline data
    model.neg_seq_len = 10
    best_valid_score, best_valid_result = trainer.fit(train_data, valid_data)

    item_model_id2raw_id, user_model_id2raw_id = test_data._dataset.field2id_token[
        "item_id"], test_data._dataset.field2id_token["user_id"]
    item_raw_id2baseline_id, user_raw_id2baseline_id = train_data._dataset.field2token_id[
        "item_id"], train_data._dataset.field2token_id["user_id"]

    user_model_id2baseline_id, item_model_id2baseline_id = [], []

    for user_raw_id in user_model_id2raw_id:
        baseline_user_id = user_raw_id2baseline_id[user_raw_id]
        user_model_id2baseline_id.append(baseline_user_id)

    for item_raw_id in item_model_id2raw_id:
        baseline_item_id = item_raw_id2baseline_id[item_raw_id]
        item_model_id2baseline_id.append(baseline_item_id)

    user_model_id2baseline_id = torch.LongTensor(
        user_model_id2baseline_id).to(model.device)
    item_model_id2baseline_id = torch.LongTensor(
        item_model_id2baseline_id).to(model.device)
    # model evaluation, should add convert_for_model_id to perform fair comperation
    test_result = trainer.evaluate(
        ["baseline", user_model_id2baseline_id, item_model_id2baseline_id, test_data])
    print(test_result)
