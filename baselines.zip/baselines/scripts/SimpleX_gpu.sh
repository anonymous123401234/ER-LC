#!/bin/bash
export CUDA_VISIBLE_DEVICES=1
# 超参数选项
learning_rates=(0.01 0.005 0.001)
# n_layers=(1 2 3 4)
aggregator=(mean user_attention self_attention)

# 遍历超参数组合
for lr in "${learning_rates[@]}"; do
  for aggr in "${aggregator[@]}"; do
    echo "Training model Simplex with learning rate: $lr, aggregator: $aggr"
    # 运行模型训练命令，这里假设是一个名为train_model.py的Python脚本
    # 你可以根据实际情况修改这个命令以及其参数
    python baselines/simplex_amazoncd.py --learning_rate=$lr --aggregator=$aggr --gpu_id=1 --exp_name=SimpleX-amazoncd-$lr-$aggr --wandb_project=explanain_rs_baseline
    python baselines/simplex_movielens.py --learning_rate=$lr --aggregator=$aggr --gpu_id=1 --exp_name=SimpleX-movielens-$lr-$aggr --wandb_project=explanain_rs_baseline
  done
  # done
done
