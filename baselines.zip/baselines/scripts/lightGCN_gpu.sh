#!/bin/bash
export CUDA_VISIBLE_DEVICES=0
# 超参数选项
learning_rates=(0.01 0.005 0.001)
n_layers=(1 2 3 4)

# 遍历超参数组合
for lr in "${learning_rates[@]}"; do
  for n_layer in "${n_layers[@]}"; do
    echo "Training model LightGCN with learning rate: $lr, n_layers: $n_layer"
    # 运行模型训练命令，这里假设是一个名为train_model.py的Python脚本
    # 你可以根据实际情况修改这个命令以及其参数
    python baselines/lightGCN_amazoncd.py --learning_rate=$lr --n_layers=$n_layer --gpu_id=0 --exp_name=lightGCN-$lr-$n_layer --wandb_project=explanain_rs_baseline
    python baselines/lightGCN_movielens.py --learning_rate=$lr --n_layers=$n_layer --gpu_id=0 --exp_name=lightGCN-$lr-$n_layer --wandb_project=explanain_rs_baseline
  done
done
